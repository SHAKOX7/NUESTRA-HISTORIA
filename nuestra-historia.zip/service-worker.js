self.addEventListener("install", e => {
  e.waitUntil(
    caches.open("nuestra-historia").then(cache => {
      return cache.addAll([
        "./",
        "./index.html",
        "./style.css",
        "./game.js"
      ]);
    })
  );
});