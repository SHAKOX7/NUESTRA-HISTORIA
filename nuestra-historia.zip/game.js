const btn = document.getElementById("playBtn");
const msg = document.getElementById("message");
const music = document.getElementById("music");

btn.addEventListener("click", () => {
  music.play();
  msg.innerText = "Gracias por quedarte 💖";
  btn.innerText = "TE AMO";
  localStorage.setItem("played", "true");
});

if (localStorage.getItem("played")) {
  msg.innerText = "Bienvenida otra vez, SHAKO'S GIRL 💙";
}